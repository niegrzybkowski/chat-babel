import json
import boto3
import time
from boto3.dynamodb.conditions import Key, Attr

DATABASE = boto3.resource('dynamodb')
TABLE = DATABASE.Table('MESSAGES')

MAX_LOOKBEHIND_SECONDS = 3600

def get_messages(event, context):
    """
    Function to get all messages from a room sent within some period of time.
    Uses GET method.
    Params:
    - RoomID: room name from which the messages are to be returned
    - Seconds: the number of seconds to be considered (value 500 means that messages from last 500 seconds will be returned, default value: 3600)
    Returns:
    - items: all the messages from the database sent whithin the set time period
    """
    roomID = event["queryStringParameters"]["RoomID"]
    try:
        seconds = int(event["queryStringParameters"]["Seconds"])
        if seconds <= 0 or seconds > MAX_LOOKBEHIND_SECONDS:
            raise ValueError()
    except:
        seconds = MAX_LOOKBEHIND_SECONDS
        
    current_time = int(time.time())
    
    response = TABLE.scan(FilterExpression=Attr("ROOM_ID").eq(roomID) & Attr("Time").gte((current_time - seconds)*1000))
    items = response["Items"]
    
    return {
        'statusCode': 200,
        'body': json.dumps({
            "items": items,
        }, default=str)
    }
   
