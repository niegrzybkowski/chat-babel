import json
import boto3

DATABASE = boto3.resource('dynamodb')
TABLE = DATABASE.Table('ROOMS')

def get_rooms(event, context):
    """
    Function to get all available rooms.
    Uses GET method.
    Returns:
    - rooms: all rooms available
    """
    try:
        rooms = TABLE.scan()["Items"]
    except:
        return {
        'statusCode': 400,
        'body': json.dumps('Could not retrieve room list.')
    }
    return {
        'statusCode': 200,
        'body': json.dumps({
            "items": rooms,
        }, default=str)
    }
