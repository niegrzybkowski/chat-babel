import json
import boto3
import package.requests as requests
from botocore.exceptions import ClientError

from boto3.dynamodb.conditions import Key, Attr


DATABASE = boto3.resource('dynamodb')
TABLE = DATABASE.Table('MESSAGES')
TABLE_ROOMS = DATABASE.Table('ROOMS')
URL = "https://api-free.deepl.com/v2/translate"
SECRET_NAME = "APIKey"
REGION = "us-east-1"
client = boto3.client(
    'dynamodb', 
    region_name=REGION
    )
    
client_apikey = boto3.client(
    service_name='secretsmanager', 
    region_name=REGION
    )



def translate_text(event, context):
    """
    Function to update message's translation in the database, as well as return said translation.
    Uses GET method.
    Params:
    - ID: message ID
    - lang: language to which translate the message
    Returns:
    - translated_text: Translated text
    """

    ID = event["queryStringParameters"]["ID"]
    lang = event["queryStringParameters"]["lang"]
    try:
        message = TABLE.get_item(Key={'ID':ID})["Item"]
    except KeyError:
        return {
            'statusCode': 400,
            'body': "Invalid message ID passed"
        }
        
    text = message["Text"]
    translated_text = message["Translations"][lang]
    room_name = message["ROOM_ID"]
    if translated_text is not None: # If already translated return translated text
        return {
        'statusCode': 200,
        'body': translated_text
    }
    
    try: # get secret API key
        get_secret_value_response = client_apikey.get_secret_value(
            SecretId=SECRET_NAME
        )
    except ClientError as e:
        return {
            'statusCode': 500,
            'body': "Could not reach API key"
        }
    KEY = get_secret_value_response['SecretString'][11:-2]
    
    formality = get_formality_from_room(room_name)
    if formality is None:
        return {
            'statusCode': 400,
            'body': "Message was sent in room that does not exist"
        }
    response = requests.post(URL, headers={
    'Authorization': f'DeepL-Auth-Key {KEY}'
                    },
                    data={
    'target_lang':lang,
    'text':text,
    'formality':formality
                    })
    try: #translate text
        translated_text = response.json()['translations'][0]['text']
    except:
        return {
        'statusCode': 500,
        'body': "Could not connect to translate API"
    }
    try: # update translation in database
        update_item(ID, lang, translated_text)
    except ClientError as e:
        return {
            'statusCode': 400,
            'body': e.response['Error']['Message']
        }
    return {
        'statusCode': 200,
        'body': translated_text
    }
    
def update_item(ID, lang, text):
    response = client.transact_write_items(
        TransactItems=[
            {
                'Update': {
                    'TableName': 'MESSAGES',
                    'Key': {
                        'ID': {
                            'S': ID
                        },
                        
                    },
                    'UpdateExpression': 'SET #tra.#lan = :val',
                    'ExpressionAttributeValues': {
                        ':val': {
                            'S': text
                        }
                    },
                    'ExpressionAttributeNames': {
                        '#tra': 'Translations',
                        '#lan': lang
                        
                    }
                }
            }
        ]
    )
    
def get_formality_from_room(id):
    try:
        room = TABLE_ROOMS.get_item(Key={'NAME':id})["Item"]
    except KeyError:
        return None
    mess = room["Formality"]
    if mess:
        formality = "prefer_more"
    else:
        formality = "prefer_less"
    return formality

