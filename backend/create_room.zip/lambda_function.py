import json
import boto3
from boto3.dynamodb.conditions import Key, Attr
import jsonschema

DATABASE = boto3.resource('dynamodb')
TABLE = DATABASE.Table('ROOMS')

SCHEMA = {
    "type": "object",
    "properties": {
        "NAME": {"type": "string"},
        #"Profanity": {"type": "boolean"},
        "Formality": {"type": "boolean"}
    },
    "required": ["NAME", "Formality"],
    "additionalProperties": False
}


def create_room(event, context):
    """
    Function to create a room with given name in a database. It also checks if a room already exists and raises error if it does.
    Uses POST method.
    Params:
    - NAME: name of the room to be created (it also becomes its id)
    - Formality: formality settings (true/false)
    Returns:
    - Message with created room name
    """
    params = json.loads(event["body"])
    try:
        jsonschema.validate(params, SCHEMA)
    except jsonschema.ValidationError:
        return {
            'statusCode': 400,
            'body': "Invalid parameters passed in request body"
        }
    roomName = params["NAME"]
    exists = True

    response = TABLE.get_item(Key={"NAME":roomName})
    try:
        response['Item']
    except KeyError:
        exists = False
        
    if exists:
        return {
            'statusCode': 400,
            'body': json.dumps('Room with this name already exists')
        }
    TABLE.put_item(Item=params)
    return {
            'statusCode': 200,

            'body': f"Room {roomName} has been added"
        }
        

