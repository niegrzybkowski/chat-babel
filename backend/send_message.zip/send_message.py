import json
import boto3
import jsonschema

DATABASE = boto3.resource('dynamodb')
TABLE = DATABASE.Table('MESSAGES')

SCHEMA = {
    "type": "object",
    "properties": {
        "Sender": {"type": "string"},
        "ROOM_ID": {"type": "string"},
        "Text": {"type": "string"}
    },
    "required": ["Sender", "ROOM_ID", "Text"],
    "additionalProperties": False
}


def send_message(event, context):
    """
    Function to update sent message to the database.
    Uses POST method.
    Params:
    - ROOM_ID: name of the room in which the message was sent
    - Sender: name of the sender of the message
    - Text: the contents of the message
    Returns:
    - ID: message ID
    """
    params = json.loads(event["body"])
    try:
        jsonschema.validate(params, SCHEMA)
    except jsonschema.ValidationError:
        return {
            'statusCode': 400,
            'body': "Invalid parameters passed in request body"
        }
    params["Time"] = int(event["requestContext"]["timeEpoch"])
    params["ID"] = event["requestContext"]["requestId"]
    params["Translations"] = json.loads("{\"pl\":null,\"fr\":null,\"es\":null,\"en\":null}")
    response = TABLE.put_item(Item=params)
    return {
            'statusCode': 200,
            'body': params["ID"]
        }




